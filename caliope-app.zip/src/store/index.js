import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)

export default new Vuex.Store({
  state: {
    termsAndConditionsModal:{
      dialog:false
    },
    stateTolbar:{
      stateTolbar:false,
    }
  },
  mutations: {
    hiddenTolbar(state){
        var URLactual = window.location.href;
        Vue.set(state.stateTolbar,"stateTolbar",URLactual.substr(24) === "landing-page" ? false : true);
    }
  },
  actions: {
  },
  modules: {
  }
})
