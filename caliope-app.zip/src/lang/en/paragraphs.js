const paragraphs ={
    to_register_you_must_accept_our:"To register you must accept our"
}
export default {
    paragraphs 
}