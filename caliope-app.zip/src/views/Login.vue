<template>
  <v-container fluid style="background-color:#364573; height:100%">
  <v-flex xs12 style="margin-top:10%; width:200px; margin-left:34%" />
    <v-card id="car" max-width="500" height="420" class="mx-auto" style="">
      <v-form ref="form" :v-model="true" lazy-validation autocomplete="on">
        <v-text-field
          :label="labels.email"
          style="margin-left:10%; margin-right:10%;"
          append-icon="fas fa-user-circle"
        />
        
        <v-text-field
        style="margin-left:10%; margin-right:10%"
          :label="labels.password"
          append-icon="fas fa-unlock-alt"
       />
       <br>
       <v-flex layout justify-center>
       <a href="#">{{ labels.recover_password }}</a>
       </v-flex>
       </v-form>
       <br>
       <vue-recaptcha
                sitekey="6LfRvqsUAAAAAAQCWq3hL9tchVuiKST0iFFDILir"
                class="layout column align-center"
              />
              <br>
              <v-card-actions>
                <v-flex text-center>
                  <v-btn color="yellow" style="width:65%;" @click="termsAndConditionsModal.dialog = !termsAndConditionsModal.dialog">
<strong> {{ labels.sign_in }} </strong>
</v-btn>
                </v-flex>
              </v-card-actions>
      </v-card>
      <v-card style="margin-top:1%; margin-bottom:5%; padding-top:2%; opacity:0.9" max-width="500" class="mx-auto">
        <v-flex layout justify-center>
            <a href="#">{{ labels.login_with }}</a>
        </v-flex>
        <br>
        <v-layout>
          <v-flex xs12 layout justify-center>
            <v-btn icon>
              <v-icon class="fab fa-facebook-f" />
            </v-btn>
            <v-btn icon style="margin-left:4%; margin-right:4%">
              <v-icon class="far fa-envelope" />
            </v-btn>
            <v-btn icon>
              <v-icon class="fab fa-instagram" />
            </v-btn>
          </v-flex>
        </v-layout>
      </v-card>
      <v-card style="margin-top:-4%; margin-bottom:5%; padding-top:2%; padding-bottom:2%; opacity:0.9" max-width="500" class="mx-auto">
        <v-flex layout justify-center>
            <a href="#">{{ labels.you_do_not_have_an_account }}? - {{ labels.sign_up_here }}</a>
        </v-flex>
      </v-card>
      <modal />
  </v-container>
</template>

<script>
import VueRecaptcha from "vue-recaptcha";
import {labels} from "@/lang/lang.js"
import {mapState, mapMutations} from 'vuex';
import modal from '@/components/Modals/TermsAndConditionsModal.vue'
export default {
  components:{
    VueRecaptcha,
    modal
  },
  data:()=>({
    labels:labels,
    activeBtn:0,
  }),mounted() {
    this.hiddenTolbar();
  },
  computed:{
    ...mapState(["termsAndConditionsModal"])
  },methods: {
    ...mapMutations(["hiddenTolbar"]),
  },
  }
</script>
<style >
#car{
  padding-top:2%;
  opacity:0.9;

}
    @media (max-height: 650px) {
  #car {
    margin-top: 20%;
    height:300px
  }
}
</style>
