<template>
  <v-container fluid style="background-color:#364573; height:100%">
<v-card id="car" max-width="600" height="680" class="mx-auto" style="margin-top:5%">
                <v-layout row wrap class="hidden-md-and-down">
                    <v-flex md4 style="padding-left:2%">
                        <v-flex md12 class="lbl1">
                        <span>*{{ labels.full_name }}</span>
                        </v-flex>
                        <v-flex md12 class="lbl2">
                        <span>*{{ labels.phone_number }}</span>
                        </v-flex>
                        <v-flex md12 class="lbl3">
                        <span>*{{ labels.residence_address }}</span>
                        </v-flex>
                        <v-flex md12 class="lbl4">
                        <span>*{{ labels.email }}</span>
                        </v-flex>
                        <v-flex md12 class="lbl5">
                        <span>*{{ labels.password }}</span>
                        </v-flex>
                        <v-flex md12 class="lbl6">
                        <span>*{{ labels.confirm_Password }}</span>
                        </v-flex>
                    </v-flex>
                    <v-flex md8>
                        <v-form ref="form" :v-model="true" lazy-validation autocomplete="on">
                        <v-text-field
                        style="margin-left:10%; margin-right:10%;"
                        />
                    
                        <v-text-field
                        style="margin-left:10%; margin-right:10%"
                        />

                        <v-text-field
                        style="margin-left:10%; margin-right:10%"
                        />

                        <v-text-field
                        style="margin-left:10%; margin-right:10%"
                        />

                        <v-text-field
                        style="margin-left:10%; margin-right:10%"
                        />

                        <v-text-field
                        style="margin-left:10%; margin-right:10%"
                        />
                    </v-form>
                </v-flex>
            </v-layout>

                <v-layout class="hidden-sm-and-up">
                        <v-flex md12>
                        <v-form ref="form" :v-model="true" lazy-validation autocomplete="on">
                        <v-text-field
                        style="margin-left:10%; margin-right:10%;"
                        :label="labels.full_name"
                        />
                    
                        <v-text-field
                        style="margin-left:10%; margin-right:10%"
                        :label="labels.phone_number"
                        />

                        <v-text-field
                        style="margin-left:10%; margin-right:10%"
                        :label="labels.residence_address"
                        />

                        <v-text-field
                        style="margin-left:10%; margin-right:10%"
                        :label="labels.email"
                        />

                        <v-text-field
                        style="margin-left:10%; margin-right:10%"
                        :label="labels.password"
                        />

                        <v-text-field
                        style="margin-left:10%; margin-right:10%"
                        :label="labels.confirm_Password"
                        />
                    </v-form>
                </v-flex>
                </v-layout>
                <v-flex class="hidden-sm-and-down" layout justify-center>
{{ paragraphs.to_register_you_must_accept_our }}  <a style="margin-left:3%" @click="termsAndConditionsModal.dialog = !termsAndConditionsModal.dialog">{{ labels.terms_and_conditions }}</a>
</v-flex>
                <v-flex xs12 class="hidden-md-and-up" layout justify-center>
{{ paragraphs.to_register_you_must_accept_our }}
</v-flex>
                <v-flex xs12 class="hidden-md-and-up" layout justify-center>
<a style="margin-left:3%" @click="termsAndConditionsModal.dialog = !termsAndConditionsModal.dialog">{{ labels.terms_and_conditions }}</a>
</v-flex>
       <br> 
       <vue-recaptcha
                sitekey="6LfRvqsUAAAAAAQCWq3hL9tchVuiKST0iFFDILir"
                class="layout column align-center"
              />
              <br>
              <v-card-actions>
                <v-flex text-center>
                  <v-btn color="yellow" style="width:65%;">
<strong> {{ labels.sign_up }} </strong>
</v-btn>
                </v-flex>
              </v-card-actions>
      </v-card>
      <v-card style="margin-top:1%; margin-bottom:5%; padding-top:2%; opacity:0.9" max-width="600" class="mx-auto">
        <v-flex layout justify-center>
            <a href="#">{{ labels.login_with }}</a>
        </v-flex>
        <br>
        <v-layout>
          <v-flex xs12 layout justify-center>
            <v-btn icon>
              <v-icon class="fab fa-facebook-f" />
            </v-btn>
            <v-btn icon style="margin-left:4%; margin-right:4%">
              <v-icon class="far fa-envelope" />
            </v-btn>
            <v-btn icon>
              <v-icon class="fab fa-instagram" />
            </v-btn>
          </v-flex>
        </v-layout>
      </v-card>
      <modal />
  </v-container>
</template>

<script>
import VueRecaptcha from "vue-recaptcha";
import {labels,paragraphs} from "@/lang/lang.js"
import {mapState} from 'vuex';
import modal from '@/components/Modals/TermsAndConditionsModal.vue'
export default {
  components:{
    VueRecaptcha,
    modal
  },
  data:()=>({
    labels:labels,
    paragraphs:paragraphs,
    activeBtn:0,
  }),computed:{
    ...mapState(["termsAndConditionsModal"])
  }
  }
</script>
<style >
#car{
  padding-top:2%;
  opacity:0.9;
}
    @media (max-height: 650px) {
  #car {
    margin-top: 20%;
    height:300px
  }
}
.lbl1{
    margin-top: 16%;
    float:right;
}
.lbl2{
    margin-top: 22%;
    float:right;
}
.lbl3{
    margin-top: 22%;
    float:right;
}
.lbl4{
    margin-top: 25%;
    float:right;
}
.lbl5{
    margin-top: 25%;
    float:right;
}
.lbl6{
    margin-top: 25%;
    float:right;
}
</style>
